#include <iostream>

using namespace std;

int main()
{
    char a,b,c,d;
    int num;
    cout<<"������һ����λ��"<<endl;
    cin >>num;
    a=(num/1000)+13+64;
    b=(num/100)%10+13+64;
    c=(num/10)%10+13+64;
    d=num%10+13+64;
    cout<<a<<b<<c<<d<<endl;
    return 0;
}

