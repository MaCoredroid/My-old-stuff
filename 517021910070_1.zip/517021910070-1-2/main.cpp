#include <iostream>

using namespace std;

int main()
{
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    cout<<a<<" "<<b<<" "<<c<<" "<<d<<"�ĸ�����ƽ��ֵΪ"<<0.25*(a+b+c+d)<<endl;
    return 0;
}
