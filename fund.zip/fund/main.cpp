#include <iostream>

using namespace std;

int main()
{
    int money,a,CP,CV;
    float Q;
    int i;

    float IR,AVG;
    float n[5];
    bool flag=0;
    do{
   cout<<"Please input your money(>1000, and multiple):"<<endl;
   cin>>money;
   if(money%1000!=0)
    cout<<money<<"is not multiple of 1000."<<endl;
   else if (money<1000)
    cout<<money<<"<1000"<<endl;
   else flag=1;
   }while(flag==0);
   a=money;
   cout<<"Please input everyday net value in this week:"<<endl;
   for(i=1;i<6;i++)
   cin>>n[i];
   cout<<"Quotient\t"<<"Net Value\t"<<"Increase Rate\t"<<"Current Value\t"<<"Current Payoff\t"<<endl;
   n[0]=1;
   for(i=1;i<6;i++)
   {
   Q=a*(1-0.015);
   IR=(n[i]-n[i-1])*100/n[i-1];
   CV=Q*n[i];
   CP=CV*(1-0.005)-a;
   IR=((float)((int)(IR*100)))/100;
   cout<<Q<<"\t"<<"\t"<<n[i]<<"\t"<<"\t"<<IR<<"%"<<"\t"<<"\t"<<CV<<"\t"<<"\t"<<CP<<"\t"<<"\t"<<endl;}
   AVG=(n[1]+n[2]+n[3]+n[4]+n[5])/5;
   cout<<"Average Net Value in this week ="<<AVG<<endl;

   return 0;





}
