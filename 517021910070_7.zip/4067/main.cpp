#include <iostream>

using namespace std;

int main()
{
    char ch[60];
    int i,len=0;
    for(i=0; i<52; i++)
        ch[i]='a';
    cin>>ch;
    for(i=0; i<52; i++)
    {

        if(ch[i]=='a')
        {
            len=i-1;
            break;
        }
    }

    for(i=len-1; i>=0; i--)
    {

        if(ch[i]=='9')
            ch[i]='0';
        else
        {
            ch[i]++;
            break;
        }
    }
    if(ch[0]=='0')
       {
           cout<<'1'<<ch;
       }
    else
        cout<<ch;
    return 0;
}
