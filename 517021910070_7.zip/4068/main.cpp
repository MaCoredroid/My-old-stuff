#include <iostream>
using namespace std;
int main()
{
    char ch[100];
    int n,i,a,len=0;
    for (i=0;i<100;i++)
        ch[i]=' ';
    cin>>n;
    cin>>ch;
    while(ch[len++]!='\0');
        len=len--;//ͳ���ַ�������
    if(n==1)
        cout<<ch;
    else
    {
       for(a=0; a<=len; a=a+2*(n-1))
        {
          if(ch[a]!=' '&&ch[a]!='\0')
                cout<<ch[a];
          else
                break;
        }//�����һ��
        for(i=1; i<n-1; i++)
        {
            for(a=i; a<=len; a=a+2*(n-1))
            {
                if(ch[a]!=' '&&ch[a]!='\0')
                    cout<<ch[a];
                else
                    break;
               if(ch[a+2*(n-i-1)]!=' '&&ch[a+2*(n-i-1)]!='\0')
                    cout<<ch[a+2*(n-i-1)];
                else
                    break;

            }
        }//�����2��n-1��
        for(a=n-1; a<=len; a=a+2*(n-1))
        {
            if(ch[a]!=' '&&ch[a]!='\0')
                cout<<ch[a];
            else
                break;
        }//������һ��
    }
    return 0;
}
