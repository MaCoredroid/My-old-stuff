#include <iostream>

using namespace std;


int main()
{
    int year,i,day,weekday,month,num1;
    i=1970;
    day=0;
    cout<<"��������Ҫ��ӡ�����"<<endl;
    cin>>year;
    for(i=1970; i<year; ++i)
    {
        day=day+365;
        if(i%400==0||(i%4==0&&i%100!=0))
            day=day+1;
    }
    weekday=(day+4)%7;
    for(month=1; month<=12; month++)
    {
        cout<<"������\t\t"<<"����һ\t\t"<<"���ڶ�\t\t"<<"������\t\t"<<"������\t\t"<<"������\t\t"<<"������\t\t"<<endl;
        switch(month)
        {
        case 4:
        case 6:
        case 9:
        case 11:
            num1=30;
            break;
        case 2:
            if (year%400==0||year%4==0&&year%100!=0)
                num1=29;
            else num1=28;
            break;
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            num1=31;
            break;
        }
        for(i=0; i<weekday; ++i)
            cout<<"\t"<<"\t";
        for(i=1; i<=num1; i++)
        {
            if (month>=10&&i>=10)
                cout<<month<<"��"<<i<<"��"<<"\t";
            else
                cout<<month<<"��"<<i<<"��"<<"\t"<<"\t";
            weekday=(weekday+1)%7;
            if(weekday==0)
                cout<<endl;
        }

        cout<<endl;
    }

    return 0;




}
