#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int i,max=0,b=0;
    int a[100];
   for(i=0; i<100; i++)
    a[i]=0;
    for(i=0; i<100; i++)
        {cin>>a[i];
         if(getchar()=='\n')
            break;  }


    for(i=1; i<a[0]+1; i++)
    {
        if(a[i]>max)
        {
            max=a[i];
            b=i;
        }
    }
    cout<<max<<" "<<b;

}
