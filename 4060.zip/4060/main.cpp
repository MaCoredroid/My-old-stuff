#include <iostream>
#include<stdio.h>
using namespace std;
int a[100];
int i,n,t;

void in()
{
    int k,temp;

    cin>>n;
    for(i=0; i<n; i++)
    {
        cin>>a[i];

    }

}
int min(int a,int b)
{
    return (a>b)?b:a;
}
int main()
{




    int k,ans=0;

    in();


    if(n==1)
    {
        ans+=a[0];
        cout<<ans;
        return 0;
    }
    for(i=n-1; i>2; i=i-2)
    {
        ans+=min(a[i]+a[0]+a[i-1]+a[0],a[1]+a[0]+a[i]+a[1]);
    }
    if(n%2==0)
    {


        ans+=a[1];
    }
    else
    {

        ans+=a[2]+a[1]+a[0];
    }



    cout<<ans;
    return 0;
}




