#include <iostream>
#include<cstring>
#include <string.h>
#include <stdio.h>
#include<cassert>
using namespace std;

int main()
{
    int n,i,k=0,m=0,len,c,d,e,f,s;
    bool emmm=0;
    cout<<"Please input the number of lines:"<<endl;
    cin>>n;//delete'/n'on the last input,use getchar
    getchar();
    char *string1[n];//to store A
    char *string2[n];//to store B
    char *out1[n];//to store the output of A
    bool *p=new bool[n];
    assert(p!=0);
    bool flag[80];

    for(i=0; i<n; i++)
    {
        string1[i]=new char[80];
        assert(string1[i]!=0);
        string2[i]=new char[80];
        assert(string2[i]!=0);
        out1[i]=new char[80];
        assert(out1[i]!=0);
        *(p+i)=0;
    }//initialization
    for(i=0; i<n; i++)
        out1[i]="\0";//initialization
    cout<<"Please input data"<<endl;;
    for(i=0; i<n; i++)
    {
        cin.getline(string1[i],80,' ');
        cin.getline(string2[i],80);
    }//the input section via cin.getline
    for(i=0; i<n; i++)

    {
        if(*(p+i)==0)
        {
            out1[m]=string1[i];
            for(k=i+1; k<n; k++)
            {
                if( strcmp(string1[i],string1[k])==0)
                {
                    *(p+k)=1;
                }
            }
            m++;
        }
        else
            continue;


    }//pick out the overlap part in A
    cout<<out1[0];//in case there is a ',' before the first output
    for(i=1; i<m; i++)
    {
        cout<<','<<out1[i];
    }
    cout<<endl;//outputA
    for(i=0; i<n; i++)
    {
        delete (p+n);
    }
    for(i=0; i<n; i++)
    {
        e=strlen(string2[i]);//e is the length of a line of B

        for(d=0; d<80; d++)
            flag[d]=0;//initialization
        for(s=0; s<m; s++)//compare every output A to B
        {

            len=strlen(out1[s]);//the len of an output of A
            for(k=2; *(string2[i]+k)!='\0' ;) //neglect the first two"->"
            {
                if(strncmp(&(*(string2[i]+k)),out1[s],len)==0)
                {

                    for(c=k; c<k+len; c++)
                        flag[c]=1;
                    k+=len;
                }//if there is an overlap,sign it and skip over
                else
                    k++;

            }
        }
        for(d=2; d<e; d++)//emmm is a bool sign , in case the first output contains a',' before it
        {


            if(flag[d]==0&&*(string2[i]+d)!=' '&&emmm==0)
            {
                cout<<*(string2[i]+d);
                emmm=1;
                continue;
            }
            if(flag[d]==0&&*(string2[i]+d)!=' '&&emmm==1)
                cout<<','<<*(string2[i]+d);//output B
        }


    }
    for(i=0; i<n; i++)
    {
        delete []string2[i];
        delete []out1[i];
        delete []string1[i];
    }
    return 0;
}


/*void dels(char a[], char b[])  //�ú�������ɾ��ָ�����Ӵ�
{
    size_t len_b = strlen(b);  //Ҫɾ�����ַ�������;

    for(size_t i = 0; a[i] != '\0';)
    {
        if(strncmp(&a[i], b, len_b) == 0)  //����strncmp������ a[i] ��λ���� b �Ƚ�
            i += len_b;   //������ͬ,ʹ i �� len_b , �´δ����λ�ü��;
        else
        {
            putchar(a[i]);   //�������ͬ�ĵط�;
            i++;
        }
    }
}*/
